//Author Name: Philip Trinh
//Date: 07/22/2023
//Course ID: CS-320
//Description: This is the unit tests for the task class (TaskTest).

package test;

import org.junit.jupiter.api.Test;
import taskService.Task;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

class TaskTest {
	/*
	 * The following tests exercise the Task class. The first 3 tests make sure
	 * the field does not become longer than the constraint (10 characters for
	 * task Id, 20 characters for task name, and 50 characters for task description).
	 * The last 2 tests ensure that each field is not null.
	 * TaskId is not tested for being not null because there isn't a way to
	 * create a contact with a null TaskId. Likewise, it is not tested for being
	 * non-update-able because there is no way to update it.
	 */
	
	@Test //Task Id Long
	@DisplayName("Task Id cannot be longer than 10 characters")
	void testTaskIdTooLong() {
		Task task = new Task("Name", "Description");
		if (task.getTaskId().length() > 10) {
			fail("Task Id is longer than 10 characters.");
		}
	}

	@Test //Task Name Long
	@DisplayName("Task Name cannot be longer than 20 characters")
	void testTaskNameTooLong() {
		Task task = new Task("MyTaskNameIsWayLongerThan20Characters", "Description");
		if (task.getTaskName().length() > 20) {
			fail("Task Name is longer than 20 characters.");
		}
	}

	@Test //Task Description Long
	@DisplayName("Task Description cannot be longer than 50 characters")
	void testTaskDescriptionTooLong() {
		Task task = new Task("Name", "MyTaskDescriptionIsWayLongerThan50Characters"
				+ "MyTaskDescriptionIsWayLongerThan50Characters");
		if (task.getTaskDescription().length() > 50) {
			fail("Task Description is longer than 50 characters.");
		}
	}

	@Test //Task Name Not Null
	@DisplayName("Task Name not null")
	void testTaskNameNotNull() {
		Task task = new Task(null, "Description");
		assertNotNull(task.getTaskName(), "Task Name null.");
	}
	
	@Test //Task Description Not Null
	@DisplayName("Task Description not null")
	void testTaskDescriptionNotNull() {
		Task task = new Task("Name", null);
		assertNotNull(task.getTaskDescription(), "Task Description null.");
	}
}