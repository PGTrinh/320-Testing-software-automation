//Author Name: Philip Trinh
//Date: 07/16/2023
//Course ID: CS-320
//Description: This is the unit tests for the task service (TaskServiceTest)

package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import org.junit.jupiter.api.DisplayName;

import taskService.Task;
import taskService.TaskService;

public class TaskServiceTest {

		/*
		 * The following tests exercise the TaskService class. In each test, a new
		 * service is created with default values for each field. Then the service is
		 * requested to make some change to the list of tasks and the result is
		 * tested to ensure the actual field matches what is expected.
		 *
		 * Because each task that gets created has a new automatically assigned
		 * taskId, and the tests are run based on that taskId, the order in which
		 * the tests are run depend on the value of each taskId. Therefore,
		 * the @Order annotation is used to keep the tests in a specific order.
		 *
		 * For evidence that the taskId is correct for each test, prior to each assertion 
		 * the records are displayed on the console for error checking.
		 */
		
		@Test //Update Task Name
		@DisplayName("Test to Update task name")
		@Order(1)
		void testUpdateTaskName() {
			TaskService service = new TaskService();
			service.addTask("Task Name", "Description"); //add task
			service.updateTaskName("New Name", "2"); //update name to New Name in task ID 2
			service.displayTaskList(); //display task list
			//assertEquals verify if new value is match expected
			assertEquals("New Name", service.getTask("2").getTaskName(), "Task name was not updated.");
		}

		@Test //Update Task Description
		@DisplayName("Test to Update task description.")
		@Order(2)
		void testUpdateTaskDescription() {
			TaskService service = new TaskService();
			service.addTask("Task Name", "Description");
			service.updateTaskDescription("Updated Description", "4"); //updated description in task ID 4
			service.displayTaskList(); //display task list
			//assertEquals verify if new value is match expected
			assertEquals("Updated Description", service.getTask("4").getTaskDescription(), "Task description was not updated.");
		}

		@Test //Delete Task
		@DisplayName("Test to ensure that service correctly deletes tasks.")
		@Order(5)
		void testDeleteTask() {
			TaskService service = new TaskService(); //create task
			service.addTask("Task Name", "Description");
			service.deleteTask("6"); //choose to delete task 6
			// Ensure that the contactList is now empty by creating a new empty contactList to compare it with
			ArrayList<Task> taskListEmpty = new ArrayList<Task>();
			service.displayTaskList(); //display task list
			//assertEquals verify if contact list is empty which will match expected
			assertEquals(service.taskList, taskListEmpty, "The contact was not deleted.");
		}

		@Test //Add task
		@DisplayName("Test to ensure that service can add a task.")
		@Order(6)
		void testAddTask() {
			TaskService service = new TaskService(); //create new task service
			service.addTask("Task Name", "Task Successfully Added"); //add task
			service.displayTaskList(); //display task list
			//assertNotNull verify that task is not null and check task 0 ID in the list to ensure it is added
			assertNotNull(service.getTask("0"), "Task was not added correctly.");
		}
}
