//Author Name: Philip Trinh
//Date: 07/22/2023
//Course ID: CS-320
//Description: This is the Task class. It creates and stores task object with ID, name, and description.

package taskService;

import java.util.concurrent.atomic.AtomicLong;

public class Task {
	private final String taskId;
	private String taskName;
	private String taskDescription;
	private static AtomicLong idGenerator = new AtomicLong();
	
	// CONSTRUCTORS
	/*
	 * Constructor takes task Id, task name, and task description as parameters. 
	 * The parameters are check and ensure it is not null or empty. If it is, fill with "NULL"
	 * so that something exists to protect data integrity while making it clear it is a placeholder. 
	 * All parameters are truncated to meet requirements, Task Id max is 10 characters, 
	 * task name is 20 characters, and description is 50 characters.
	 */
	public Task(String taskName, String taskDescription) {
		
		// taskId
		// Task Id is generated when the constructor is called. It is set as a final variable and has
		// no other getter or setter so there should be no way to change it.
		// The idGenerator is static to prevent duplicates across all task.
		this.taskId = String.valueOf(idGenerator.getAndIncrement());
		
		// taskName
		if (taskName == null || taskName.isEmpty()) {
			this.taskName = "NULL";
		} else if (taskName.length() > 20) {
			this.taskName = taskName.substring(0, 20);
		} else {
			this.taskName = taskName;
		}
		
		// taskDescription
		if (taskDescription== null || taskDescription.isEmpty()) {
			this.taskDescription= "NULL";
		} else if (taskDescription.length() > 50) {
			this.taskDescription= taskDescription.substring(0, 50);
		} else {
			this.taskDescription= taskDescription;
		}
	}
	
	// GETTERS
	public String getTaskId() {
		return taskId;
	}
	
	public String getTaskName() {
		return taskName;
	}
	
	public String getTaskDescription() {
		return taskDescription;
	}
	
	// SETTERS
	/*
	 * The setters follow the same rules as the constructor.
	 */
	public void setTaskName(String taskName) {
		if (taskName == null || taskName.isEmpty()) {
			this.taskName = "NULL";
		} else if (taskName.length() > 20) {
			this.taskName = taskName.substring(0, 20);
		} else {
			this.taskName = taskName;
		}
	}
	
	public void setTaskDescription(String taskDescription) {
		if (taskDescription== null || taskDescription.isEmpty()) {
			this.taskDescription= "NULL";
		} else if (taskDescription.length() > 50) {
			this.taskDescription= taskDescription.substring(0, 50);
		} else {
			this.taskDescription= taskDescription;
		}
	}
}