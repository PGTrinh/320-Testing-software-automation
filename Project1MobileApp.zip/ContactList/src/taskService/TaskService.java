//Author Name: Philip Trinh
//Date: 07/22/2023
//Course ID: CS-320
//Description: This is Task Service Class, purpose of these services is to add, update, and delete task objects within the application.

package taskService;

import java.util.ArrayList; //use array list to save task

public class TaskService {
	// Start with an ArrayList of tasks to hold the list of tasks
	public ArrayList<Task> taskList = new ArrayList<Task>();

	// Display the full list of tasks to the console for error checking.
	public void displayTaskList() {
		for (int counter = 0; counter < taskList.size(); counter++) {
			System.out.println("\t Task ID: " + taskList.get(counter).getTaskId());
			System.out.println("\t Task Name: " + taskList.get(counter).getTaskName());
			System.out.println("\t Task Description: " + taskList.get(counter).getTaskDescription());
		}
	}

	// Adds a new task using the Task constructor, then assign the new task to the list.
	public void addTask(String taskName, String TaskDescription) {
		// Create the new task
		Task task = new Task(taskName, TaskDescription);
		taskList.add(task);
	}

	// Using Task Id, return a task object
	// If a matching Task Id is not found, return a task object with default values
	public Task getTask(String taskId) {
		Task task = new Task(null, null);
		for (int counter = 0; counter < taskList.size(); counter++) {
			if (taskList.get(counter).getTaskId().contentEquals(taskId)) {
				task = taskList.get(counter);
			}
		}
		return task;
	}

	// Delete task.
	// Use the taskId to find the right task to delete from the list
	// If we get to the end of the list without finding a match for taskId report that to the console.
	// This method of searching for taskId is the same for all update methods below.
	public void deleteTask(String taskId) {
		for (int counter = 0; counter < taskList.size(); counter++) {
			if (taskList.get(counter).getTaskId().equals(taskId)) {
				taskList.remove(counter);
				break;
			}
			if (counter == taskList.size() - 1) {
				System.out.println("Task Id: " + taskId + " not found.");
			}
		}
	}

	// Update the task name.
	public void updateTaskName(String updatedString, String taskId) {
		for (int counter = 0; counter < taskList.size(); counter++) {
			if (taskList.get(counter).getTaskId().equals(taskId)) {
				taskList.get(counter).setTaskName(updatedString);
				break;
			}
			if (counter == taskList.size() - 1) {
				System.out.println("Task Id: " + taskId + " not found.");
			}
		}
	}

	// Update the task description.
	public void updateTaskDescription(String updatedString, String taskId) {
		for (int counter = 0; counter < taskList.size(); counter++) {
			if (taskList.get(counter).getTaskId().equals(taskId)) {
				taskList.get(counter).setTaskDescription(updatedString);
				break;
			}
			if (counter == taskList.size() - 1) {
				System.out.println("Task Id: " + taskId + " not found.");
			}
		}
	}
}
