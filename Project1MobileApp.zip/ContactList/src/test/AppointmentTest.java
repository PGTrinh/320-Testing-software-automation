//Author Name: Philip Trinh
//Date: 07/28/2023
//Course ID: CS-320
//Description: This is the unit tests for the Appointment class (AppointmentTest)

package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Calendar;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Appointment.Appointment;

class AppointmentTest {

	/*
	 * The following tests exercise the Appointment class. The first 2 tests make sure
	 * the field does not become longer than the constraint (10 characters for
	 * task Id and 50 characters for task description).
	 * Then following test to ensure appointment date is not in the past.
	 * The last 2 tests ensure that each field is not null.
	 * AppointmentId is not tested for being not null because there isn't a way to
	 * create an appointment with a null Id. Likewise, it is not tested for being
	 * non-update-able because there is no way to update it.
	 */
	
	private Date Date(int a, int july, int b) {
		return null;
	}
	@Test //Appointment ID long
	@DisplayName("Appointment Id cannot be longer than 10 characters")
	void testAppointmentIdTooLong() {
		Appointment appointment = new Appointment(Date(2023, Calendar.JULY, 28), "Description");
		if (appointment.getAppointmentId().length() > 10) {
			fail("Appointment Id is longer than 10 characters.");
		}
	}

	@Test //Appointment Description long
	@DisplayName("Appoinment description cannot be longer than 50 characters")
	void testAppointmentDescriptionTooLong() {
		Appointment appointment = new Appointment(Date(2023, Calendar.JULY, 28), "MyAppointmentDescriptionIsWayLongerThan50Characters" 
				+ "MyAppointmentDescriptionIsWayLongerThan50Characters" 
				+ "MyAppointmentDescriptionIsWayLongerThan50Characters");
		if (appointment.getAppointmentDescription().length() > 50) {
			fail("Appointment Description is longer than 50 characters.");
		}
	}
	
	@Test //Appointment Date in the past
	@DisplayName("Appointment Date cannot be in the past")
	void testAppointmentDateInThePast() {
	    /// Set the current date 
	    Calendar calendar = Calendar.getInstance();
	    calendar.set(2023, Calendar.JULY, 28);
	    //add the current date to calendar 
	    Date currentDate = calendar.getTime();
	    
	    // Create a new appointment to test (if date is in the past of the set date, it should fail)
	    calendar.set(2023, Calendar.DECEMBER, 28);
	    Date newDate = calendar.getTime();
	    Appointment appointment = new Appointment(newDate, "Description");
	    
	    // fail if the appointment date is in the past
	    if (appointment.getAppointmentDate().before(currentDate)) {
	        fail("Appointment Date is in the past.");
	    }
	}
	
	@Test //Appointment Date not null
	@DisplayName("Appoinment Date not null")
	void testAppointmentDateNotNull() {
		Appointment appointment = new Appointment(null, "Description");
		assertNotNull(appointment.getAppointmentDate(), "Appointment Date was null.");
	}
	
	@Test //Appointment Description not null
	@DisplayName("Appoinment Description not null")
	void testAppointmentDescNotNull() {
		Appointment task = new Appointment(Date(2023, Calendar.JULY, 28), null);
		assertNotNull(task.getAppointmentDescription(), "Appointment Description was null.");
	}
}