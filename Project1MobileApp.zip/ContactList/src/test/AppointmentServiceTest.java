//Author Name: Philip Trinh
//Date: 07/28/2023
//Course ID: CS-320
//Description: This is the unit tests for the appointment service (AppointmentServiceTest)

package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.util.Calendar;
import java.util.Date;
import java.util.ArrayList;
import Appointment.Appointment;
import Appointment.AppointmentService;

class AppointmentServiceTest {
	/*
	 * The following tests exercise the AppointmentService class. In each test, a new
	 * service is created with default values for each field. Then the service is
	 * requested to make some change to the list of tasks and the result is
	 * tested to ensure the actual field matches what is expected.
	 *
	 * Because each appointment that gets created has a new automatically assigned
	 * appointmentId, and the tests are run based on that appointmentId, the order in which
	 * the tests are run depend on the value of each appointmentId. Therefore,
	 * the @Order annotation is used to keep the tests in a specific order.
	 *
	 * For evidence that the appointmentId is correct for each test, prior to each assertion 
	 * the records are displayed on the console for error checking.
	 */
	private Date Date(int a, int july, int b) {
		return null;
	}
	@Test //Update Appointment date
	@DisplayName("Test to update appointment date")
	@Order(1)
	void testUpdateAppointmentDate() {
		AppointmentService service = new AppointmentService(); //create new appointment
		// Create a Calendar instance and set it to the desired date (August 22, 2023)
	    Calendar appointmentDate = Calendar.getInstance();
	    appointmentDate.set(2023, Calendar.AUGUST, 22);
	    // Convert the Calendar to a Date object
	    Date date = appointmentDate.getTime();
	    // Add an appointment with the initial date
	    service.addAppointment(date, "Description");
	    // Update the appointment date to a new date 
	    Calendar newAppointmentDate = Calendar.getInstance();
	    newAppointmentDate.set(2023, Calendar.DECEMBER, 15);
	    // Convert the new Calendar to a Date object
	    Date newDate = newAppointmentDate.getTime();
	    // Update the appointment with the new date
	    service.updateAppointmentDate(newDate, "2");
	    // Display the appointment list 
	    service.displayAppointmentList();
	    //assertEquals verify the appointment in the appointment list is updated 
	    assertEquals(newDate, service.getAppointment("2").getAppointmentDate(), "Appointment date was not updated.");
	}
	
	@Test //Update Appointment description
	@DisplayName("Test to update appointment description.")
	@Order(2)
	void testUpdateAppointmentDescription() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(Date(2023, Calendar.JULY, 28), "Description");
		service.updateAppointmentDescription("New Description", "5");
		service.displayAppointmentList();
		assertEquals("New Description", service.getAppointment("5").getAppointmentDescription(), "Appointment description was not updated.");
	}

	@Test //Delete Appointment
	@DisplayName("Test to ensure that service correctly deletes appointments.")
	@Order(3)
	void testDeleteAppointment() {
		AppointmentService service = new AppointmentService(); 
		service.addAppointment(Date(2023, Calendar.JULY, 28), "Description");
		service.deleteAppointment("4");
		// Ensure that the AppointmentList is now empty by creating a new empty AppointmentList to compare with it
		ArrayList<Appointment> appointmentListEmpty = new ArrayList<Appointment>();
		service.displayAppointmentList();  //display appointment list
		//assertEquals verify if appointment list is empty which will match expected
		assertEquals(service.appointmentList, appointmentListEmpty, "The appointment was not deleted.");
	}

	@Test //Add Appointment
	@DisplayName("Test to ensure that service can add an appointment.")
	@Order(4)
	void testAddAppointment() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(Date(2023, Calendar.DECEMBER, 15), "Description");
		service.displayAppointmentList();
		//assertNotNull verify that appointment is not null and check task 0 Id in the list to ensure it is added
		assertNotNull(service.getAppointment("0"), "Appointment was not added correctly.");
	}
}
