//Author Name: Philip Trinh
//Date: 07/28/2023
//Course ID: CS-320
//Description: Appointment class, created to add tasks with ID, name, date, and description.

package Appointment;

import java.util.concurrent.atomic.AtomicLong;
import java.util.Date;
import java.util.Calendar;

public class Appointment {
	private final String appointmentId;
	private Date appointmentDate;
	private String appointmentDescription;
	private static AtomicLong idGenerator = new AtomicLong();
	
	// CONSTRUCTORS
	/*
	 * Constructor takes appointment Id, appointment date, and appointment description as parameters. 
	 * All parameters are checked to ensure not null or empty. If it is, fill with "NULL" so that something
	 * exist to protect data integrity while making it clear that it is a placeholder. All parameters are truncated 
	 * to meet requirements. Appointment Id max is 10 characters, appointment date must be present or future (cannot be in the past), 
	 * and description max is 50 characters.
	 */

	public Appointment(Date appointmentDate, String appointmentDescription) {
		
		// Appointment Id
		// Appointment Id is auto generated when the constructor is called. It is set as a final variable and has
		// no other getter or setter so there should be no way to change it.
		// The idGenerator is static to prevent duplicates across all tasks.
		this.appointmentId = String.valueOf(idGenerator.getAndIncrement());
		
		// Appointment Date
		if (appointmentDate == null) {
			Calendar calendar = Calendar.getInstance();
			calendar.set(2023, Calendar.JULY, 28); //set the calendar to current date
			this.appointmentDate = calendar.getTime(); //adopt calendar date for appointmentDate
		} else if (appointmentDate.before(new Date())) //prevent add date in the past
		{   
			throw new IllegalArgumentException("ERROR, Appointment Date cannot be in the past");
		} else {
			this.appointmentDate = appointmentDate;
		}
		
		// Appointment Description
		if (appointmentDescription == null || appointmentDescription.isEmpty()) {
			this.appointmentDescription = "NULL";
		} else if (appointmentDescription.length() > 50) {
			this.appointmentDescription = appointmentDescription.substring(0, 50);
		} else {
			this.appointmentDescription= appointmentDescription;
		}
	}
	
	// GETTERS
	public String getAppointmentId() {
		return appointmentId;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public String getAppointmentDescription() {
		return appointmentDescription;
	}
	
	// SETTERS
	/*
	 * The setters follow the same rules as the constructor.
	 */
	public void setAppointmentDate(Date appointmentDate) {
		if (appointmentDate == null) {
			Calendar calendar = Calendar.getInstance();
			calendar.set(2023, Calendar.JULY, 28); //set the calendar to current date
			this.appointmentDate = calendar.getTime(); //adopt calendar date for appointmentDate
		} else if (appointmentDate.before(new Date())) //prevent add date in the past
		{
			throw new IllegalArgumentException("Cannot make appointment before current date.");
		} else {
			this.appointmentDate = appointmentDate;
		}
	}
	public void setAppointmentDescription(String appointmentDescription) {
		if (appointmentDescription == null || appointmentDescription.isEmpty()) {
			this.appointmentDescription = "NULL";
		} else if (appointmentDescription.length() > 50) {
			this.appointmentDescription = appointmentDescription.substring(0, 50);
		} else {
			this.appointmentDescription = appointmentDescription;
		}
	}
}