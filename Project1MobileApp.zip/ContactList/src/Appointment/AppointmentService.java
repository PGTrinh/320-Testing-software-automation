//Author Name: Philip Trinh
//Date: 07/28/2023
//Course ID: CS-320
//Description: Appointment Service class, purpose of this class is to add/delete/update 
//appointment objects using Appointment Id.

package Appointment;

import java.util.Date;
import java.util.ArrayList;

public class AppointmentService {
	// Start with an ArrayList of appointments to hold the appointments
	public ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();
	// Display the full list of appointments to the console for error checking.
	public void displayAppointmentList() {
		for (int counter = 0; counter < appointmentList.size(); counter++) {
			System.out.println("\t Appointment Id: " + appointmentList.get(counter).getAppointmentId());
			System.out.println("\t Appointment Date: " + appointmentList.get(counter).getAppointmentDate());
			System.out.println("\t Appointment Description: " + appointmentList.get(counter).getAppointmentDescription());
		}
	}
	// Adds a new appointment using the Appointment constructor, then assigns it to the list.
	public void addAppointment(Date appointmentDate, String appointmentDescription) {
		// Create the new appointment
		Appointment appointment = new Appointment(appointmentDate, appointmentDescription);
		appointmentList.add(appointment);
	}
	// Using Appointment Id, return an appointment object
	// If a matching Id is not found, return an appointment object with default values
	public Appointment getAppointment(String appointmentId) {
		Appointment appointment = new Appointment(null, null);
		for (int counter = 0; counter < appointmentList.size(); counter++) {
			if (appointmentList.get(counter).getAppointmentId().contentEquals(appointmentId)) {
				appointment = appointmentList.get(counter);
			}
		}
		return appointment;
	}
	// Delete appointment.
	// Use the appointmentId to find the right appointment to delete from the list
	// If we get to the end of the list without finding a match for ID, report that to the console.
	// This method of searching for appointmentID is the same for all update methods below.
	public void deleteAppointment(String appointmentId) {
		for (int counter = 0; counter < appointmentList.size(); counter++) {
			if (appointmentList.get(counter).getAppointmentId().equals(appointmentId)) {
				appointmentList.remove(counter);
				break; //if found break loop
			}
			if (counter == appointmentList.size() - 1) { //when it reach the end of list still not found
				System.out.println("Appointment Id: " + appointmentId + " not found.");
			}
		}
	}
	// Update the appointment date.
	public void updateAppointmentDate(Date updatedDate, String appointmentId) {
		for (int counter = 0; counter < appointmentList.size(); counter++) {
			if (appointmentList.get(counter).getAppointmentId().equals(appointmentId)) {
				appointmentList.get(counter).setAppointmentDate(updatedDate);
				break; //if found break loop
			}
			if (counter == appointmentList.size() - 1) //when it reach the end of list still not found
			{
				System.out.println("Appointment Id: " + appointmentId + " not found.");
			}
		}
	}
	// Update the appointment description.
	public void updateAppointmentDescription(String updatedString, String appointmentId) {
		for (int counter = 0; counter < appointmentList.size(); counter++) {
			if (appointmentList.get(counter).getAppointmentId().equals(appointmentId)) {
				appointmentList.get(counter).setAppointmentDescription(updatedString);
				break; //if found break loop
			}
			if (counter == appointmentList.size() - 1) //when it reach the end of list still not found
			{
				System.out.println("Appointment Id: " + appointmentId + " not found.");
			}
		}
	}
}
