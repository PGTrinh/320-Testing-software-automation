package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import mobileApp.Contact;

class ContactTest {

	@Test
	void testContact() {
		Contact contact = new Contact ("123456", "Philip", "Trinh", "0123456789", "Hawaii");
		assertTrue(contact.getContactId().equals("123456"));
		assertTrue(contact.getFirstName().equals("Philip"));
		assertTrue(contact.getLastName().equals("Trinh"));
		assertTrue(contact.getPhone().equals("0123456789"));
		assertTrue(contact.getAddress().equals("Hawaii"));
	}
	@Test // test if contact ID is null 
	void testContactIdIsNull() {
		//Assertions test if getting an exception, if does not get exception will show error
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Philip", "Trinh", "0123456789", "Hawaii");
		}); }
	@Test // test if contact ID is longer than 10 chars
	void testContactIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678900", "Philip", "Trinh", "0123456789", "Hawaii");
		}); }
	@Test // test if first name is longer than 10 chars
	void testFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", null, "Trinh", "0123456789", "Hawaii");
		}); }
	@Test // test if first name is longer than 10 chars
	void testFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "PhilipCS320", "Trinh", "0123456789", "Hawaii");
		}); }
	@Test // test if last name is null 
	void testLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678", "Philip", null, "0123456789", "Hawaii");
		}); }
	@Test // test if last name is longer than 10 chars
	void testLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678", "Philip", "TrinhPhilip", "0123456789", "Hawaii");
		}); }
	@Test // test if phone is null
	void testPhoneIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "Philip", "Trinh", null, "Hawaii");
		}); }
	@Test // test if phone is longer than 10 chars
	void testPhoneTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "PhilipCS320", "Trinh", "01234567890", "Hawaii");
		}); }
	@Test // test if phone is less than 10 chars
	void testPhoneTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "PhilipCS320", "Trinh", "012345678", "Hawaii");
		}); }
	@Test // test if address is null
	void testAddressIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "Philip", "Trinh", "0123456789", null);
		}); }
	@Test // test if address is longer than 30 chars
	void testAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "PhilipCS320", "Trinh", "0123456789", "WelcomeToHawaiiTheBestVacation!");
		}); }
}

