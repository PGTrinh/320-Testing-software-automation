package test;

import org.junit.jupiter.api.Assertions;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;

import mobileApp.Contact;
import mobileApp.ContactService;

public class ContactServiceTest {

    private ContactService contactService;

    @Before //annotate method that needs to be executed before each test case
    public void Initialize() {
    	//creates a new instance of the ContactService class, initializing the contactService variable
        contactService = new ContactService();
        //Clear contactList before each test case to ensure list is empty prior to test
        ContactService.getContactList().clear(); }
    @Test
    public void testAddContact() { //test if contact is added successful into the contactList
        //create new contact with all necessary details
    	Contact contact = new Contact("1234567", "Philip", "Trinh", "0123456789", "Hawaii");
        //add contact to ContactService
    	contactService.addContact(contact);
    	//obtain Array List to retrieve list of contacts store in contact service 
        ArrayList<Contact> contactList = ContactService.getContactList();
        //assertEquals check if the contactList size equal to 1, meaning it successfully added
        Assert.assertEquals(1, contactList.size());
        //assertTrue check if contactList contains contact object to ensure addContact method correctly adds the contact
        Assert.assertTrue(contactList.contains(contact));
    }

    @Test
    public void testAddNullContact() { //test if contact is null
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(null);
        });
    }

    @Test
   //Test if contact ID is unique, expect throw exception when add two contact with same ID
    public void testAddDuplicateContactId() { 
        Contact contact1 = new Contact("123456", "Philip", "Trinh", "0123456789", "Hawaii");
        Contact contact2 = new Contact("123456", "Phuc", "Smith", "9876543210", "Texas");
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(contact1);
            contactService.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() { //test if can delete contact per contact ID
    	//create a contact and add to contactService
        Contact contact = new Contact("123456", "Philip", "Trinh", "0123456789", "Hawaii");
        contactService.addContact(contact);
        //delete contact with contact ID added previously
        contactService.deleteContact("123456");
        //pull contactList
        ArrayList<Contact> contactList = ContactService.getContactList();
        //assertEquals check if the contact list size is now 0
        Assert.assertEquals(0, contactList.size());
        //assertFalse check if the contact list no longer hold contact (successfully delete)
        Assert.assertFalse(contactList.contains(contact));
    }

    @Test
    public void testDeleteInvalidContactIdId() { //test if can delete contact ID that not exist
    	//create a contact and add to contactService
        Contact contact = new Contact("123456", "Philip", "Trinh", "0123456789", "Hawaii");
        contactService.addContact(contact);
    	//delete contact with contact ID "InvalidId" the exception should throw
        //since "InvalidID" does not exist in contactService 
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
        contactService.deleteContact("InvalidId");
        });
    }
    @Test
    public void testUpdateFirstName() { //test update first name
        Contact contact = new Contact("123456", "Philip", "Trinh", "0123456789", "Hawaii");
        contactService.addContact(contact);
        contactService.updateFirstName("123456", "Phuc");
        //assert equals verifies that the first name of the contact has been successfully 
        //updated to "Phuc" by comparing it with the current existing first name in contact list.
        Assert.assertEquals("Phuc", contact.getFirstName());
    }

    @Test
    public void testUpdateFirstNameInvalidContactId() {//test if can update first name with an invalid ID
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	//the contact ID "InvalidId" does not match any valid contact in the ContactService
        	//the updateFirstName method should throw an IllegalArgumentException.
            contactService.updateFirstName("InvalidId", "Phuc");
        });
    }
    @Test
    public void testUpdateLastName() { //test update last name
        Contact contact = new Contact("123456", "Philip", "Trinh", "0123456789", "Hawaii");
        contactService.addContact(contact);
        contactService.updateLastName("123456", "Ho");
        //assert equals verifies that the last name of the contact has been successfully 
        //updated to "Ho" by comparing it with the current existing first name in contact list.
        Assert.assertEquals("Ho", contact.getLastName());
    }

    @Test
    public void testUpdateLastNameInvalidContactId() {//test if can update last name with an invalid ID
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	//the contact ID "InvalidId" does not match any valid contact in the ContactService
        	//the updateFirstName method should throw an IllegalArgumentException.
            contactService.updateLastName("InvalidId", "Ho");
        });
    }
    @Test
    public void testUpdatePhone() { //test update phone
        Contact contact = new Contact("123456", "Philip", "Trinh", "0123456789", "Hawaii");
        contactService.addContact(contact);
        contactService.updatePhone("123456", "9876543210");
        //assert equals verifies that the phone of the contact has been successfully 
        //updated to "9876543210" by comparing it with the current existing phone in contact list.
        Assert.assertEquals("9876543210", contact.getPhone());
    }

    @Test
    public void testUpdatePhoneInvalidContactId() {//test if can update last name with an invalid ID
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	//the contact ID "InvalidId" does not match any valid contact in the ContactService
        	//the updatePhone method should throw an IllegalArgumentException.
            contactService.updatePhone("InvalidId", "9876543210");
        });
    }
    @Test
    public void testUpdateAddress() { //test update address
        Contact contact = new Contact("123456", "Philip", "Trinh", "0123456789", "Hawaii");
        contactService.addContact(contact);
        contactService.updateAddress("123456", "Texas");
        //assert equals verifies that the address of the contact has been successfully 
        //updated to "Texas" by comparing it with the current existing address in contact list.
        Assert.assertEquals("Texas", contact.getAddress());
    }

    @Test
    public void testUpdateAddressInvalidContactId() {//test if can update last name with an invalid ID
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	//the contact ID "InvalidId" does not match any valid contact in the ContactService
        	//the updateAddress method should throw an IllegalArgumentException.
            contactService.updateAddress("InvalidId", "Texas");
        });
    }
    @Test
    //test method GetContactById when try to retrieve contact using an Invalid ID
    public void testGetContactByIdInvalidId() { 
        Contact contact = new Contact("123456", "Philip", "Trinh", "0123456789", "Hawaii");
        contactService.addContact(contact);
        
        //test using an invalid ID 
        Contact result = contactService.getContactByID("InvalidId");
        //assertion checks if the result is equal to null
        //since provided ID does not match any ID in contactService
        Assertions.assertEquals(null, result);
    }
}