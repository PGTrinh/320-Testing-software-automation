package mobileApp;

import java.util.ArrayList; //use array list to save contact

public class ContactService {
	////store list of the contactList
    private static ArrayList<Contact> contactList = new ArrayList<>(); 
    //Add contacts method
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }
        //get contact ID and check with new ID to see if new ID match any existing ID 
        String contactId = contact.getContactId();
        for (Contact existingContact : getContactList()) {
            if (existingContact.getContactId().equals(contactId)) {
            	//if exist throw argument that contact ID existed
                throw new IllegalArgumentException("Contact with ID " + contactId + " already exists");
            }
        }
        //if no match, add contact to contact list
        getContactList().add(contact);
    }
    //Delete contacts method
    public void deleteContact(String contactId) {
    	//check contact ID is in the list using validateContactID method
        validateContactId(contactId);
        //retrieve the contact ID and remove contact
        Contact contact = getContactByID(contactId);
        getContactList().remove(contact);
    }   
    //Update first name method
    public void updateFirstName(String contactId, String firstName) {
    	//check contact ID is in the list using validateContactID method
        validateContactId(contactId);
        //retrieve the contact ID and update first name
        Contact contact = getContactByID(contactId);
        contact.setFirstName(firstName);
    }
    //Update last name method
    public void updateLastName(String contactId, String lastName) {
    	//check contact ID is in the list using validateContactID method
        validateContactId(contactId);
        Contact contact = getContactByID(contactId);
        //retrieve the contact ID and update last name
        contact.setLastName(lastName);
    }
    //Update phone method
    public void updatePhone(String contactId, String phone) {
    	//check contact ID is in the list using validateContactID method
        validateContactId(contactId);
        Contact contact = getContactByID(contactId);
        //retrieve the contact ID and update phone
        contact.setPhone(phone);
    } 
    //Update address method
    public void updateAddress(String contactId, String address) {
    	//check contact ID is in the list using validateContactID method
        validateContactId(contactId);
        Contact contact = getContactByID(contactId);
        //retrieve the contact ID and update address
        contact.setAddress(address);
    }
    //validate contactId is valid and exist
    private void validateContactId(String contactId) {
        if (contactId == null || contactId.isEmpty() || !isContactIdExists(contactId)) {
            throw new IllegalArgumentException("Invalid contact ID");
        }
    }
    //validate contact Id exist return true, if not return false
    private boolean isContactIdExists(String contactId) {
        for (Contact contact : getContactList()) {
            if (contact.getContactId().equals(contactId)) {
                return true;
            }
        }
        return false;
    }
    //Getter for contact ID if exist return contact, if not return null
    public Contact getContactByID(String contactID) {
        for (Contact contact : getContactList()) {
            if (contact.getContactId().equals(contactID)) {
                return contact;
            }
        }
        return null;
    }
    //getter for contactList
	public static ArrayList<Contact> getContactList() {
		return contactList;
	}
	//setter for contactList
	public static void setContactList(ArrayList<Contact> contactList) {
		ContactService.contactList = contactList;
	}
}